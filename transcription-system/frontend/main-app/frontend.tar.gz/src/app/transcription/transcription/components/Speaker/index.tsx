export { default } from './Speaker';
export { SpeakerManager } from './utils/speakerManager';
export type { SpeakerData } from './utils/speakerManager';