import DevelopmentHub from './DevelopmentHub';

export default function DevelopmentPage() {
  return <DevelopmentHub />;
}